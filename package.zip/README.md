shaarfox
========

Webapp for shaarli



WebL10N
-------

Thanks to  Fabien Cazenave for webL10n:
https://github.com/fabi1cazenave/webL10n
